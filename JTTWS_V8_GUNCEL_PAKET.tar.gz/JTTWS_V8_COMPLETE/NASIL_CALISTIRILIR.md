# 🚀 JTTWS V8 BOT NASIL ÇALIŞTIRILIR?

## 📋 İÇİNDEKİLER
1. [Sistem Gereksinimleri](#sistem-gereksinimleri)
2. [Kurulum](#kurulum)
3. [Hızlı Başlangıç](#hızlı-başlangıç)
4. [Detaylı Kullanım](#detaylı-kullanım)
5. [Sorun Giderme](#sorun-giderme)

---

## 🖥️ SİSTEM GEREKSİNİMLERİ

### Minimum:
- **OS:** Windows 10/11, macOS 10.15+, Linux (Ubuntu 20.04+)
- **Python:** 3.8 veya üzeri
- **RAM:** 4GB (8GB önerilen)
- **Disk:** 2GB boş alan
- **İnternet:** Sadece kurulum için

### Python Kontrolü:
```bash
python --version
# veya
python3 --version
```

**Çıktı şöyle olmalı:** `Python 3.8.x` veya daha yükseği

---

## 📦 KURULUM

### ADIM 1: JTTWS_V8_COMPLETE Klasörünü İndirin

Emergent platformundan veya verilen linkten indirin.

### ADIM 2: Klasöre Girin

```bash
# Terminal açın ve klasöre gidin
cd /path/to/JTTWS_V8_COMPLETE

# Örnek (macOS/Linux):
cd ~/Downloads/JTTWS_V8_COMPLETE

# Örnek (Windows):
cd C:\Users\YourName\Downloads\JTTWS_V8_COMPLETE
```

### ADIM 3: Virtual Environment Oluşturun (Önerilen)

```bash
# Virtual environment oluştur
python3 -m venv trading_env

# Aktif et (macOS/Linux):
source trading_env/bin/activate

# Aktif et (Windows):
trading_env\Scripts\activate
```

**Başarılı olursa:** Terminal'de `(trading_env)` yazısı görünecek.

### ADIM 4: Bağımlılıkları Kurun

```bash
# requirements.txt'deki tüm paketleri kur
pip install -r requirements.txt
```

**Kurulacak Paketler:**
- stable-baselines3 (PPO agent)
- optuna (hyperparameter optimization)
- gym (environment)
- torch (neural networks)
- pandas, numpy (data processing)
- vectorbt (backtesting)

**Kurulum Süresi:** 2-5 dakika (internet hızına göre)

### ADIM 5: Kurulum Kontrolü

```bash
# Modülleri test et
python3 -c "import stable_baselines3, optuna, pandas; print('✅ Kurulum başarılı!')"
```

**Beklenen Çıktı:** `✅ Kurulum başarılı!`

---

## ⚡ HIZLI BAŞLANGIÇ

### Senaryo 1: HEMEN TRAINING BAŞLAT (En Hızlı)

```bash
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 10 --years 2020-2024
```

**Ne Yapıyor?**
- ✅ Daily aggregate data yükler (data/aggregated/)
- ✅ Walk-forward training başlatır (180/60 window)
- ✅ 10 Optuna trial per period
- ✅ 2020-2024 yılları arasındaki verilerle
- ✅ Sonuçları outputs/ klasörüne kaydeder

**Süre:** ~5-10 dakika (27 period için)

**Çıktı Örneği:**
```
2025-11-07 12:00:00 - INFO - 🚀 UltimateTradingSystemV8 initialized (PPO: True)
2025-11-07 12:00:01 - INFO - 📂 Loading data: 2020-2024
2025-11-07 12:00:02 - INFO -   ✓ EURUSD: 1802 days
2025-11-07 12:00:03 - INFO -   ✓ GBPUSD: 1800 days
2025-11-07 12:00:04 - INFO -   ✓ USDJPY: 1827 days
...
📈 WalkForwardTrainer initialized:
   Data samples: 1827
   Train window: 180 days
   Test window: 60 days
...
✅ Walk-Forward Complete!
   Results saved: outputs/walk_forward_results_v8.csv
```

---

### Senaryo 2: DATA TEST (Veriler Doğru Yükleniyor mu?)

```bash
python data_manager_v8.py
```

**Ne Yapıyor?**
- ✅ EURUSD/GBPUSD/USDJPY data yükler
- ✅ Weekly ranges yükler
- ✅ Economic calendar yükler
- ✅ Özet rapor gösterir

**Çıktı Örneği:**
```
INFO:DataManagerV8:📂 DataManagerV8 initialized
INFO:DataManagerV8:📥 Loading EURUSD data...
INFO:DataManagerV8:✅ Loaded 1802 days for EURUSD

✅ EURUSD Data Shape: (1802, 11)
   timestamp                open     high      low    close  volume
0  2020-01-01 00:00:00  1.12160  1.12210  1.12120  1.12180    5432
...
```

---

### Senaryo 3: DATA AGGREGATION TEST

```bash
python data_aggregator_v8.py
```

**Ne Yapıyor?**
- ✅ 15M veriden daily aggregate oluşturur (eğer varsa)
- ✅ Sharpe, reward, returns hesaplar
- ✅ Walk-forward data hazırlar

---

## 🎯 DETAYLI KULLANIM

### 1️⃣ WALK-FORWARD TRAINING (Full)

```bash
python ultimate_bot_v8_ppo.py \
  --mode train \
  --optuna-trials 50 \
  --years 2020-2024
```

**Parametreler:**
- `--mode train`: Walk-forward training modu
- `--optuna-trials 50`: Her period için 50 optimization trial
- `--years 2020-2024`: Kullanılacak yıl aralığı

**Süre:** ~20-30 dakika
**Sonuç:** `outputs/walk_forward_results_v8.csv`

---

### 2️⃣ BACKTEST MODU (Eğer 15M Ham Veri Varsa)

```bash
python ultimate_bot_v8_ppo.py \
  --mode backtest \
  --years 2020-2024 \
  --use-ppo
```

**Parametreler:**
- `--mode backtest`: Backtest modu (tek geçiş)
- `--use-ppo`: PPO agent kullan (default: DQN)

**Not:** 15M ham data gerekli (EURUSD2003-2024/ klasörleri)

---

### 3️⃣ TEST MODU (Eğitilmiş Model ile)

```bash
python ultimate_bot_v8_ppo.py \
  --mode test \
  --years 2024-2024
```

**Gerekli:** Önceden eğitilmiş model (`models/` klasöründe)

---

### 4️⃣ PAPER TRADING MODU (Gelecekte)

```bash
python ultimate_bot_v8_ppo.py \
  --mode paper \
  --broker mt5
```

**Not:** MT5 entegrasyonu gerekli (gelecek versiyon)

---

## 📊 SONUÇLARI İNCELEME

### Walk-Forward Results Analizi:

```bash
# CSV'yi görüntüle
cat outputs/walk_forward_results_v8.csv

# veya Python ile:
python -c "import pandas as pd; df = pd.read_csv('outputs/walk_forward_results_v8.csv'); print(df.head(10))"
```

**Önemli Sütunlar:**
- `train_sharpe`: Train dönemi Sharpe Ratio
- `test_sharpe`: Test dönemi Sharpe Ratio (out-of-sample)
- `decay_percent`: Decay yüzdesi (overfitting göstergesi)
- `best_lr`: Optimal learning rate
- `best_clip_range`: Optimal clip range

---

### Raporları Okuma:

```bash
# Comprehensive V7 vs V8 karşılaştırma
cat V7_VS_V8_COMPARISON_REPORT.md

# Grok önerileri ve implementation
cat V8_GROK_UPDATES_SUMMARY.md

# Verification report
cat FINAL_VERIFICATION_REPORT.md
```

---

## 🔧 GELİŞMİŞ AYARLAR

### Kendi Verilerinizi Kullanma:

Eğer 15M OHLCV verileriniz varsa:

```bash
# 1. Veriyi data/ klasörüne kopyalayın
cp -r /path/to/EURUSD2003-2024 data/

# 2. DataManager test edin
python data_manager_v8.py

# 3. Backtest çalıştırın
python ultimate_bot_v8_ppo.py --mode backtest --years 2020-2024
```

**Veri Formatı:**
```
Local time,Open,High,Low,Close,Volume
2020-01-01 00:00:00,1.12160,1.12210,1.12120,1.12180,5432
2020-01-01 00:15:00,1.12180,1.12230,1.12150,1.12200,4821
...
```

---

### Hyperparameter Tuning:

Optuna parametrelerini değiştirmek için:

```python
# optuna_optimizer.py dosyasını düzenleyin

# Learning rate range (satır ~80)
lr = trial.suggest_float('lr', 1e-5, 1e-2, log=True)

# Clip range (satır ~81)
clip_range = trial.suggest_float('clip_range', 0.1, 0.3)
```

---

### Walk-Forward Window Değiştirme:

```python
# walk_forward_trainer.py dosyasını düzenleyin

# Train window (satır ~42)
window_train: int = 180,  # 180 gün yerine 90, 120, 240 deneyin

# Test window (satır ~43)
window_test: int = 60,  # 60 gün yerine 30, 45, 90 deneyin
```

---

## ❓ SORUN GİDERME

### Sorun 1: "ModuleNotFoundError: No module named 'stable_baselines3'"

**Çözüm:**
```bash
pip install stable-baselines3
# veya tümünü tekrar kur
pip install -r requirements.txt
```

---

### Sorun 2: "FileNotFoundError: data/aggregated/EURUSD_daily_2020_2024.csv"

**Çözüm:**
```bash
# Data klasörünü kontrol et
ls data/aggregated/

# Eğer boşsa, data_aggregator_v8.py çalıştır
python data_aggregator_v8.py
```

---

### Sorun 3: "CUDA not available" (GPU ile çalıştırmak istiyorsanız)

**Çözüm:**
```bash
# PyTorch CUDA versiyonunu kurun
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

**Not:** CPU ile de çalışır, biraz daha yavaş.

---

### Sorun 4: "Gym has been unmaintained" Warning

**Normal:** Bu bir uyarı, kod çalışmaya devam eder.

**Gerekirse:**
```bash
pip install gymnasium
```

---

### Sorun 5: Training Çok Yavaş

**Çözüm:**
1. Optuna trials azaltın: `--optuna-trials 5`
2. Yıl aralığını daraltın: `--years 2023-2024`
3. GPU kullanın (eğer varsa)

---

## 📚 EK KAYNAKLAR

### Dokümantasyon:
- `README_V8.md` - Genel bakış
- `DATA_UPLOAD_README.md` - Veri yükleme
- `V7_VS_V8_COMPARISON_REPORT.md` - Performance analizi
- `V8_GROK_UPDATES_SUMMARY.md` - Technical details

### Python Dokümantasyonu:
```python
# Ultimate Bot V8
python -c "import ultimate_bot_v8_ppo; help(ultimate_bot_v8_ppo)"

# Data Manager
python -c "from data_manager_v8 import DataManagerV8; help(DataManagerV8)"
```

---

## 🎯 ÖNERİLEN İŞ AKIŞI

### İlk Kez Kullanıyorsanız:

```bash
# 1. Kurulum kontrolü
python -c "import stable_baselines3; print('✅ OK')"

# 2. Data test
python data_manager_v8.py

# 3. Kısa training (test için)
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 5 --years 2023-2024

# 4. Sonuçları incele
cat outputs/walk_forward_results_v8.csv

# 5. Full training (eğer sonuç iyise)
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 50 --years 2020-2024
```

---

### Günlük Kullanım:

```bash
# 1. Virtual env aktif et
source trading_env/bin/activate

# 2. Training çalıştır
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 50 --years 2020-2024

# 3. Sonuçları analiz et
python -c "
import pandas as pd
df = pd.read_csv('outputs/walk_forward_results_v8.csv')
print(f'Avg Train Sharpe: {df[\"train_sharpe\"].mean():.3f}')
print(f'Avg Test Sharpe: {df[\"test_sharpe\"].mean():.3f}')
print(f'Avg Decay: {df[\"decay_percent\"].mean():.2f}%')
"

# 4. Deaktive et
deactivate
```

---

## 🚀 ÖZETİN ÖZETİ

**3 Komutla Başla:**

```bash
# 1. Kur
pip install -r requirements.txt

# 2. Test Et
python data_manager_v8.py

# 3. Çalıştır
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 10 --years 2020-2024
```

**10 dakika sonra:**
- ✅ Walk-forward training tamamlanır
- ✅ Sonuçlar outputs/ klasöründe
- ✅ V7 vs V8 karşılaştırması yapabilirsiniz

---

**🎉 Başarılar! Sorularınız için:** `data/README_DATA.md` ve diğer dokümantasyonlara bakın!

# 📊 JTTWS V8 DATA KLASÖRÜ

## ✅ BU KLASÖRDE NELER VAR?

### 1️⃣ **aggregated/** Klasörü (920KB) ⭐⭐⭐

Daily aggregate OHLCV verileri (2020-2024):

- **EURUSD_daily_2020_2024.csv** (305KB, 1,802 gün)
- **GBPUSD_daily_2020_2024.csv** (303KB, 1,800 gün)
- **USDJPY_daily_2020_2024.csv** (305KB, 1,827 gün)

**Sütunlar:**
```
date, open, high, low, close, volume, returns, rolling_mean, rolling_std, 
sharpe, cum_returns, reward
```

**Kullanım:**
- ✅ Walk-forward training (HIZLI - zaten aggregate edilmiş)
- ✅ Backtesting (günlük stratejiler için)
- ✅ Performance analysis

---

### 2️⃣ **Weekly Ranges** (410KB)

Haftalık high/low/range/ATR istatistikleri (2003-2025):

- **EURUSD_weekly_ranges.csv** (139KB, 1,117 hafta)
- **GBPUSD_weekly_ranges.csv** (138KB, 1,117 hafta)
- **USDJPY_weekly_ranges.csv** (133KB, 1,117 hafta)

**Sütunlar:**
```
time, high, low, close, atr, ma, range, range_pips
```

**Kullanım:**
- ✅ Volatility filters
- ✅ ATR-based risk management
- ✅ Weekly range predictions

---

### 3️⃣ **Economic Calendar** (9.5MB)

Ekonomik olaylar (2003-2024+):

- **combined_economic_calendar.csv** (9.5MB, 83,522 events)

**Sütunlar:**
```
Id, Start, Name, Impact, Currency, datetime, Category
```

**Kullanım:**
- ✅ News blackout filtering
- ✅ High-impact event avoidance
- ✅ Fundamental analysis

---

## 🔍 TOPLAM BOYUT

**Mevcut:** ~11 MB (daily + weekly + calendar)

**Eksik:** 15-dakikalık ham OHLCV verisi (~1.2GB)

---

## ❓ 15 DAKİKALIK VERİLER NEREDE?

### NEDEN EKLENMEDİ?
- 📦 **Boyut:** ~1.2GB (çok büyük, download zorlaşır)
- ⏱️ **Training:** Daily data yeterli (walk-forward 180/60 gün için)
- 💾 **Yer:** GitHub/Email limitleri

### HAM VERİYİ NEREDEN ALABILIRIM?

**Seçenek 1: Kendi Verileriniz**
Eğer zaten ~/Desktop/JTTWS/data/ klasöründe verileriniz varsa:
```bash
# Lokal bilgisayarınızda
cp -r ~/Desktop/JTTWS/data/EURUSD2003-2024 /path/to/JTTWS_V8_COMPLETE/data/
cp -r ~/Desktop/JTTWS/data/GBPUSD2003-2024 /path/to/JTTWS_V8_COMPLETE/data/
cp -r ~/Desktop/JTTWS/data/USDJPY2003-2024 /path/to/JTTWS_V8_COMPLETE/data/
```

**Seçenek 2: Dukascopy (Ücretsiz)**
```bash
# 15M forex data indirme (örnek: EURUSD 2020-2024)
# https://www.dukascopy.com/swiss/english/marketwatch/historical/
```

**Seçenek 3: Mock Data ile Test**
```bash
# DataManagerV8 otomatik mock data üretir
python data_manager_v8.py
# use_mock=True ile gerçekçi simülasyon
```

---

## 🚀 HIZLI TEST (Mevcut Verilerle)

### 1. Daily Data ile Training:
```bash
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 10 --years 2020-2024
```
✅ **Çalışır!** Daily data yeterli.

### 2. 15M Data ile Training (Ham veri gerekli):
```bash
# Önce ham veriyi yükleyin, sonra:
python ultimate_bot_v8_ppo.py --mode backtest --years 2020-2024
```
⚠️ 15M ham veri gerekli (EURUSD2003-2024/ klasörleri).

---

## 📁 DOSYA YAPISI

```
data/
├── aggregated/                    (920KB, HAZIR ✅)
│   ├── EURUSD_daily_2020_2024.csv
│   ├── GBPUSD_daily_2020_2024.csv
│   └── USDJPY_daily_2020_2024.csv
├── EURUSD_weekly_ranges.csv       (139KB, HAZIR ✅)
├── GBPUSD_weekly_ranges.csv       (138KB, HAZIR ✅)
├── USDJPY_weekly_ranges.csv       (133KB, HAZIR ✅)
├── combined_economic_calendar.csv (9.5MB, HAZIR ✅)
├── EURUSD2003-2024/               (KULLANICI EKLEMELİ ⏳)
│   └── *.csv (9 dosya, 15M bars)
├── GBPUSD2003-2024/               (KULLANICI EKLEMELİ ⏳)
│   └── *.csv (9 dosya, 15M bars)
└── USDJPY2003-2024/               (KULLANICI EKLEMELİ ⏳)
    └── *.csv (9 dosya, 15M bars)
```

---

## ✅ NE YAPILIR?

### Senaryo A: Walk-Forward Training (HEMEN!)
**Gerekli:** ✅ Mevcut veriler (daily + weekly + calendar)
```bash
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 50 --years 2020-2024
```
**Sonuç:** 27 period, 180/60 window training başarılı!

### Senaryo B: Intraday Backtest (15M Stratejileri)
**Gerekli:** ⏳ Ham 15M data eklenmeli
```bash
# 1. Ham veriyi ekle (EURUSD2003-2024/ klasörleri)
# 2. Test:
python data_manager_v8.py
# 3. Backtest:
python ultimate_bot_v8_ppo.py --mode backtest --years 2020-2024
```

---

## 🎯 SONUÇ

**Mevcut verilerle:**
- ✅ Walk-forward training (180/60 gün)
- ✅ Daily stratejiler
- ✅ Optuna optimization
- ✅ V7 vs V8 comparison

**Ham veri ile:**
- ✅ Intraday backtesting (15M)
- ✅ Scalping stratejileri
- ✅ High-frequency analysis

**Önerimiz:** Mevcut verilerle başlayın, gerekirse ham veri ekleyin!

---

**Son Güncelleme:** 7 Kasım 2025  
**Durum:** ✅ Daily Data Ready | ⏳ 15M Data Optional

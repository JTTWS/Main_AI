# ⚡ HIZLI BAŞLANGIÇ REHBERİ - 3 ADIMDA BAŞLA!

## 🎯 3 ADIM, 10 DAKİKA, TRAINING BAŞLASIN!

---

## 📥 ADIM 1: İNDİR VE HAZIRLA (2 dakika)

### 1.1. Klasörü İndir
JTTWS_V8_COMPLETE klasörünü bilgisayarınıza indirin.

### 1.2. Terminal Aç
- **macOS:** Terminal uygulamasını aç
- **Windows:** CMD veya PowerShell aç
- **Linux:** Terminal aç

### 1.3. Klasöre Git
```bash
cd ~/Downloads/JTTWS_V8_COMPLETE
```

**✅ Doğrulama:**
```bash
ls
# requirements.txt ve diğer dosyalar görünmeli
```

---

## 🔧 ADIM 2: KUR (3 dakika)

### 2.1. Python Kontrolü
```bash
python3 --version
```
**Beklenen:** Python 3.8 veya üzeri

### 2.2. Virtual Environment (Opsiyonel ama Önerilen)
```bash
python3 -m venv trading_env
source trading_env/bin/activate  # macOS/Linux
# veya
trading_env\Scripts\activate  # Windows
```

### 2.3. Paketleri Kur
```bash
pip install -r requirements.txt
```

**Kurulacaklar:**
- stable-baselines3
- optuna
- pandas, numpy
- torch
- gym

**✅ Doğrulama:**
```bash
python3 -c "import stable_baselines3; print('✅ Başarılı!')"
```

---

## 🚀 ADIM 3: ÇALIŞTIR! (5-10 dakika)

### Seçenek A: Hızlı Test (5 dakika)

```bash
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 10 --years 2020-2024
```

**Ne Oluyor?**
- ✅ Data yüklenir (EURUSD, GBPUSD, USDJPY)
- ✅ Walk-forward training başlar (180/60 window)
- ✅ 10 Optuna trial × 27 period = 270 optimization
- ✅ Sonuçlar `outputs/walk_forward_results_v8.csv` dosyasına kaydedilir

---

### Seçenek B: Full Training (20-30 dakika)

```bash
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 50 --years 2020-2024
```

**Daha İyi Sonuçlar:**
- 50 trial per period
- Daha optimal hyperparameter bulma
- Production-ready results

---

## 📊 SONUÇLARI GÖSTER

### Terminal'de Hızlı Özet:

```bash
python -c "
import pandas as pd
df = pd.read_csv('outputs/walk_forward_results_v8.csv')
print('\n🎯 WALK-FORWARD TRAINING SONUÇLARI:')
print(f'   Toplam Period: {len(df)}')
print(f'   Avg Train Sharpe: {df[\"train_sharpe\"].mean():.3f}')
print(f'   Avg Test Sharpe: {df[\"test_sharpe\"].mean():.3f}')
print(f'   Best Test Sharpe: {df[\"test_sharpe\"].max():.3f}')
print(f'   Avg Decay: {df[\"decay_percent\"].mean():.2f}%')
print(f'   High Decay Periods: {df[\"high_decay\"].sum()} / {len(df)}')
print('\n✅ Training tamamlandı!')
"
```

---

### CSV'yi Aç:

```bash
# Excel/Numbers ile aç
open outputs/walk_forward_results_v8.csv  # macOS
# veya
start outputs/walk_forward_results_v8.csv  # Windows
```

---

## 🎯 BEKLENTİLER

### Training Sırasında Göreceğiniz:

```
╔═══════════════════════════════════════════════════════════╗
║     JTTWS DATA KLASÖRÜ KAPSAMLI ANALİZ                   ║
╚═══════════════════════════════════════════════════════════╝

📊 Processing EURUSD...
   Output: 1802 days
   Date range: 2020-01-01 → 2024-12-31
   Avg Sharpe: 1.085

📊 Processing GBPUSD...
   Output: 1800 days
   ...

🚀 Starting walk-forward training...
   Total data points: 1827

📊 Period 1:
   Train: 2020-01-01 to 2020-06-29 (180 days)
   Test:  2020-06-30 to 2020-08-28 (60 days)

🔍 Starting Optuna optimization (10 trials)...
[I 2025-11-07] Trial 0 finished with value: 0.234...
[I 2025-11-07] Trial 1 finished with value: 0.456...
...
✅ Optimization complete!
   Best Sharpe: 0.523
   Best Parameters: lr=0.00234, clip_range=0.234...
   Test Sharpe:  0.489
   Decay: 6.5%
   ✅ Decay within threshold

📊 Period 2:
   ...

✅ Walk-Forward Complete!
   Results saved: outputs/walk_forward_results_v8.csv
```

---

## 🎓 BİLMENİZ GEREKENLER

### Training Süreleri:

| Optuna Trials | Toplam Süre | Kullanım |
|---------------|-------------|----------|
| 5 trials | ~3 dakika | Hızlı test |
| 10 trials | ~5-10 dakika | Normal test |
| 20 trials | ~10-15 dakika | İyi sonuçlar |
| 50 trials | ~20-30 dakika | Production |

---

### Parametreler Ne Demek?

**`--mode train`**
- Walk-forward training modu
- 27 period × Optuna trials

**`--optuna-trials 10`**
- Her period için 10 hyperparameter denemesi
- Daha fazla = daha iyi sonuç ama daha yavaş

**`--years 2020-2024`**
- 2020-2024 arasındaki veriler kullanılır
- Daha dar aralık = daha hızlı

---

### Sonuç Dosyası Ne İçeriyor?

`outputs/walk_forward_results_v8.csv` sütunları:

- `period`: Period numarası (1-27)
- `train_start`, `train_end`: Train dönemi tarihleri
- `test_start`, `test_end`: Test dönemi tarihleri
- `train_sharpe`: Train Sharpe Ratio
- `test_sharpe`: Test Sharpe Ratio (önemli!)
- `decay_percent`: Test/Train decay yüzdesi
- `best_lr`: Optimal learning rate
- `best_clip_range`: Optimal clip range
- `high_decay`: Decay threshold aşıldı mı?

---

## 🔧 SORUN ÇÖZME

### "ModuleNotFoundError"
```bash
pip install -r requirements.txt
```

### "FileNotFoundError: data/aggregated"
```bash
python data_aggregator_v8.py
```

### Training Çok Yavaş
```bash
# Daha az trial
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 5 --years 2023-2024
```

---

## 📚 DAHA FAZLA BİLGİ

### Detaylı Rehber:
```bash
cat NASIL_CALISTIRILIR.md
```

### Verification Report:
```bash
cat FINAL_VERIFICATION_REPORT.md
```

### V7 vs V8 Karşılaştırma:
```bash
cat V7_VS_V8_COMPARISON_REPORT.md
```

---

## ✅ CHECKLIST

Training başlatmadan önce kontrol edin:

- [ ] Python 3.8+ kurulu
- [ ] requirements.txt kuruldu
- [ ] `data/aggregated/` klasöründe CSV'ler var
- [ ] Terminal'de doğru klasördesiniz
- [ ] (Opsiyonel) Virtual environment aktif

**Hepsi tamam mı? Çalıştırın!**

```bash
python ultimate_bot_v8_ppo.py --mode train --optuna-trials 10 --years 2020-2024
```

---

## 🎉 BAŞARILAR!

**10 dakika sonra:**
- ✅ 27 period walk-forward training tamamlanmış olacak
- ✅ Real data ile test edilmiş PPO bot elinizde
- ✅ Sonuçları analiz edip V7 ile karşılaştırabilirsiniz

**Sorularınız için:** Diğer README dosyalarına bakın!

**🚀 HEMEN BAŞLAYIN!**

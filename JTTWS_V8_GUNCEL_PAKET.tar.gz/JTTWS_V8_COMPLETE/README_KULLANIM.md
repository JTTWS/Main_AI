# 🚀 ULTIMATE FTMO TRADING BOT V7.0 - KULLANIM KILAVUZU

## 📋 İÇİNDEKİLER

1. [Sistem Gereksinimleri](#sistem-gereksinimleri)
2. [Kurulum Adımları](#kurulum-adımları)
3. [Dosya Yapısı](#dosya-yapısı)
4. [Bot Nasıl Çalıştırılır](#bot-nasıl-çalıştırılır)
5. [Strateji Detayları](#strateji-detayları)
6. [Telegram Raporları](#telegram-raporları)
7. [Sorun Giderme](#sorun-giderme)
8. [SSS](#sss)

---

## 🖥️ SİSTEM GEREKSİNİMLERİ

- **İşletim Sistemi:** macOS (M1/M2/Intel)
- **Python:** 3.8 veya üzeri
- **RAM:** Minimum 4 GB
- **Depolama:** Minimum 2 GB boş alan
- **İnternet:** Telegram bildirimleri için

---

## 📦 KURULUM ADIMLARI

### Adım 1: Python Environment Hazırlığı

Terminal'i aç ve şu komutları çalıştır:

```bash
# JTTWS klasörüne git
cd ~/Desktop/JTTWS

# Virtual environment oluştur (eğer yoksa)
python3 -m venv trading_env

# Environment'ı aktifleştir
source trading_env/bin/activate
```

### Adım 2: Gerekli Kütüphaneleri Yükle

```bash
# Gerekli paketleri yükle
pip install numpy pandas scipy aiohttp

# Alternatif: requirements.txt varsa
pip install -r requirements.txt
```

### Adım 3: Veri Dosyalarını Kontrol Et

```bash
# Veri klasörünü kontrol et
ls -la ~/Desktop/JTTWS/data/

# Şunlar olmalı:
# - EURUSD2003-2024/ klasörü (içinde CSV dosyaları)
# - GBPUSD2003-2024/ klasörü
# - USDJPY2003-2024/ klasörü
# - EURUSD_weekly_ranges.csv
# - GBPUSD_weekly_ranges.csv
# - USDJPY_weekly_ranges.csv
```

**ÖNEMLİ:** Eğer weekly_ranges.csv dosyaları yoksa, bot çalışmaz!

### Adım 4: Bot Dosyasını İndir/Oluştur

```bash
# Bot dosyasının olduğunu kontrol et
ls -la ~/Desktop/JTTWS/ultimate_bot_v7_professional.py
```

---

## 📁 DOSYA YAPISI

Bilgisayarında şu yapı olmalı:

```
~/Desktop/JTTWS/
├── ultimate_bot_v7_professional.py    # Ana bot dosyası (ÖNEMLİ)
├── README_KULLANIM.md                 # Bu dosya
├── data/                              # Veri klasörü
│   ├── EURUSD2003-2024/              # EURUSD mumları
│   │   ├── EURUSD_Candlestick_15_M_BID_*.csv
│   ├── GBPUSD2003-2024/              # GBPUSD mumları
│   ├── USDJPY2003-2024/              # USDJPY mumları
│   ├── EURUSD_weekly_ranges.csv      # Haftalık range (ÖNEMLİ)
│   ├── GBPUSD_weekly_ranges.csv      # Haftalık range (ÖNEMLİ)
│   └── USDJPY_weekly_ranges.csv      # Haftalık range (ÖNEMLİ)
├── logs/                              # Log dosyaları
├── outputs/                           # Çıktı dosyaları
└── models/                            # Model dosyaları
```

---

## 🚀 BOT NASIL ÇALIŞTIRILIR

### Basit Kullanım (Backtest)

Terminal'de:

```bash
# 1. JTTWS klasörüne git
cd ~/Desktop/JTTWS

# 2. Environment'ı aktifleştir
source trading_env/bin/activate

# 3. Botu çalıştır (2020 yılı testi)
python ultimate_bot_v7_professional.py --mode backtest --years 2020 --episodes 1
```

### Tam Veri ile Test (2003-2024)

```bash
python ultimate_bot_v7_professional.py --mode backtest --years 2003-2024 --episodes 1
```

**UYARI:** Bu 30-60 dakika sürebilir!

### Son 5 Yıl Testi (Önerilen)

```bash
python ultimate_bot_v7_professional.py --mode backtest --years 2020-2024 --episodes 1
```

### Paper Trading (Simülasyon)

```bash
python ultimate_bot_v7_professional.py --mode paper
```

### Yardım Menüsü

```bash
python ultimate_bot_v7_professional.py --help
```

**Çıktı:**
```
usage: ultimate_bot_v7_professional.py [-h] [--mode {backtest,paper,train}]
                                       [--years YEARS] [--episodes EPISODES]

Ultimate FTMO Trading Bot V7.0 Professional

options:
  -h, --help            Yardım menüsü
  --mode                Mod: backtest, paper, train
  --years               Yıl aralığı: 2020-2024 veya 2020
  --episodes            Episode sayısı (default: 1)
```

---

## 📊 STRATEJİ DETAYLARI

### 1. Hak Sistemi

```
USDJPY: 25 hak/gün
EURUSD: 21 hak/gün
GBPUSD: 18 hak/gün
```

- Açılışta: hak -= 1
- TP'de: hak = min(hak+1, tavan)
- SL'de: hak değişmez

### 2. Pozisyon Parametreleri (SABİT)

```
Lot Size: 0.01 lot
Stop Loss: 20 pip
Take Profit: 40 pip
Risk/Reward: 1:2
```

### 3. İşlem Saatleri (Türkiye Saati)

```
İşlem Başlangıcı: 08:00
İşlem Bitişi: 22:00
Yeni Giriş Yasağı: 22:30'dan sonra
Zorunlu Kapanış: 23:00
```

### 4. Filtreler

#### a) Haber Filtresi
- High impact olaylar ±30 dakika giriş yok
- USD/EUR/GBP haberler takip edilir

#### b) Volatilite Koruması
- **RangeGuard:** 15M bar > p95 ise giriş yok
- **GapGuard:** Büyük fiyat sıçramalarında giriş yok
- **Sığ Saat Filtresi:** Gece 23:00-07:00 arası giriş yok

#### c) Trend Filtresi
- EMA20 > EMA50: Sadece LONG
- EMA20 < EMA50: Sadece SHORT
- Swing mesafe: Minimum 15 pip

#### d) Korelasyon Kontrolü
- EURUSD + GBPUSD aynı yönde: Max 1 pozisyon
- USDJPY karşıt: +1 tolerans

### 5. Risk Limitleri

```
Günlük Loss Cap:
- EURUSD: $21
- GBPUSD: $18
- USDJPY: $16
- Toplam: $65

Ardışık Kayıp Limiti: 5 (sonra gün boyunca dur)
```

### 6. Saatlik Hak Tahsisi

```
08:00-12:00: %40 haklar
14:00-18:00: %40 haklar
18:00-22:00: %20 haklar
```

---

## 📱 TELEGRAM RAPORLARI

### Pozisyon Açılışı Raporu

```
📈 POZİSYON AÇILDI

🔹 Sembol: EURUSD
🔹 Yön: LONG
🔹 Lot: 0.01
🔹 Giriş: 1.08500
🔹 SL: 1.08300 (-20 pip)
🔹 TP: 1.08900 (+40 pip)
🔹 Risk: $2.00

📊 İndikatörler:
  • RSI: 45.2
  • MACD: 0.0012
  • EMA20: 1.08450
  • EMA50: 1.08300
  • ATR: 0.00120

💡 Sebep: Trend aligned + Swing distance OK
⏰ Zaman: 2025-01-04 10:30:00
```

### Pozisyon Kapanış Raporu

```
✅ POZİSYON KAPANDI

🔹 Sembol: EURUSD
🔹 Yön: LONG
🔹 Giriş: 1.08500
🔹 Çıkış: 1.08900
🔹 P&L: $4.00

💡 Sebep: Take Profit
⏰ Süre: 45 dakika
```

### Engellenen Giriş Raporu

```
🚫 GİRİŞ ENGELLENDİ

🔹 Sembol: GBPUSD
🔹 Sebep: RangeGuard exceeded

📊 Detaylar:
  • Bar range: 55.2 pips
  • Threshold: 45.0 pips
  • Reason: High volatility period
```

### Günlük Özet

```
📊 GÜNLÜK ÖZET

💰 Net P&L: $12.50
📈 Kazanan: 8
📉 Kaybeden: 4
🎯 Win Rate: 66.7%
💵 Avg Win: $4.20
💸 Avg Loss: $2.10
🔢 Toplam İşlem: 12

📅 Tarih: 2025-01-04
```

---

## 🛠️ SORUN GİDERME

### Sorun 1: "No data files found"

**Çözüm:**
```bash
# Veri dosyalarını kontrol et
ls -la ~/Desktop/JTTWS/data/EURUSD2003-2024/

# Dosyalar yoksa, veri klasörünü doğru yere taşı
```

### Sorun 2: "Weekly ranges not found"

**Çözüm:**
```bash
# Weekly range dosyalarını kontrol et
ls -la ~/Desktop/JTTWS/data/*weekly*.csv

# Şu dosyalar olmalı:
# EURUSD_weekly_ranges.csv
# GBPUSD_weekly_ranges.csv
# USDJPY_weekly_ranges.csv
```

### Sorun 3: "ModuleNotFoundError"

**Çözüm:**
```bash
# Eksik kütüphaneyi yükle
pip install <eksik_kütüphane>

# Örnek:
pip install numpy pandas scipy
```

### Sorun 4: Bot trade yapmıyor

**Sebep:** Filtreler çok katı olabilir

**Kontrol Et:**
1. Hafta sonu mu? (Bot hafta içi çalışır)
2. Saat uygun mu? (08:00-22:00 TR)
3. Volatilite çok yüksek mi?
4. Haklar bitti mi?

**Log Kontrol:**
```bash
tail -50 ~/Desktop/JTTWS/logs/bot_v7_*.log
```

### Sorun 5: Telegram bildirimleri gelmiyor

**Sebep:** aiohttp kurulu değil

**Çözüm:**
```bash
pip install aiohttp
```

---

## ❓ SSS (Sık Sorulan Sorular)

### S1: Bot gerçek para ile çalışıyor mu?

**C:** HAYIR! Bot tamamen simülasyon modunda çalışır. Gerçek para kullanılmaz.

### S2: Backtest ne kadar sürer?

**C:** 
- 1 yıl: ~2-5 dakika
- 5 yıl: ~10-20 dakika
- 21 yıl: ~30-60 dakika

### S3: Telegram zorunlu mu?

**C:** Hayır, opsiyonel. Telegram yoksa loglar terminale yazılır.

### S4: Haftalık range dosyaları neden önemli?

**C:** Bot, volatilite koruması için bu dosyaları kullanır. Olmadan çalışmaz.

### S5: Strateji değiştirilebilir mi?

**C:** Evet, kod içinde Config sınıfını düzenleyerek:
- Hak sayıları
- SL/TP pip değerleri
- İşlem saatleri
- Risk limitleri
değiştirilebilir.

### S6: Canlı trading yapabilir miyim?

**C:** **HAYIR!** Bu bot sadece backtest ve paper trading içindir. Canlı trading için:
1. Broker API entegrasyonu gerekli (MT5, Interactive Brokers vb.)
2. Gerçek para riski var
3. Yasal düzenlemeler var

**ÖNERİ:** En az 3-6 ay paper trading yap, sonuçları analiz et.

### S7: Logları nerede bulabilirim?

**C:**
```bash
# Tüm loglar
ls -lh ~/Desktop/JTTWS/logs/

# Bugünün logu
tail -f ~/Desktop/JTTWS/logs/bot_v7_$(date +%Y%m%d).log
```

### S8: Bot durduğunda ne olur?

**C:** Bot kapanırken:
1. Tüm açık pozisyonları kapatır
2. Son durumu loglar
3. Telegram'a özet gönderir

### S9: Birden fazla bot çalıştırabilir miyim?

**C:** Evet, ama:
- Her bot farklı terminal'de
- Farklı yıl aralıkları ile
- Loglar karışabilir

### S10: Bot hatası verirse ne yapmalıyım?

**C:**
1. Log dosyasını kontrol et
2. Hata mesajını oku
3. "Sorun Giderme" bölümüne bak
4. Gerekirse bota sor

---

## 📞 DESTEK

Sorun yaşarsan:

1. **Log dosyalarını kontrol et**
2. **README'yi tekrar oku**
3. **Hata mesajını Google'da ara**
4. **Bana sor** (tüm detaylarla)

---

## ✅ SON KONTROL LİSTESİ

Botu çalıştırmadan önce:

- [ ] Python 3.8+ kurulu
- [ ] trading_env oluşturuldu ve aktif
- [ ] numpy, pandas, scipy, aiohttp yüklü
- [ ] JTTWS/data/ klasöründe veriler var
- [ ] Weekly range CSV dosyaları var
- [ ] ultimate_bot_v7_professional.py mevcut
- [ ] Terminal JTTWS klasöründe

**HEPSİ HAZIRSA, BAŞLAYALIM! 🚀**

```bash
cd ~/Desktop/JTTWS
source trading_env/bin/activate
python ultimate_bot_v7_professional.py --mode backtest --years 2020 --episodes 1
```

---

## 🎉 İYİ ŞANSLAR!

Bot başarıyla çalıştıysa, Telegram'dan raporları takip et ve logları incele!

**Unutma:** Bu bir öğrenme aracıdır. Gerçek para ile test etme!

---

**Son Güncelleme:** Ocak 2025
**Version:** 7.0 PROFESSIONAL
**Yazar:** E1 AI Agent + İnsan Stratejisi
